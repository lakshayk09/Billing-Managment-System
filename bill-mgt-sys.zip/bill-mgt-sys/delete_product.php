<?php

session_start();

include 'dbcon.php';

if (isset($_GET['product_id']))
{
    $order_id=$_GET['product_id'];
    $deleteQuery="DELETE FROM products where product_id=$order_id"; 
    mysqli_query($con, $deleteQuery);

    echo "<script>window.location = 'products.php';</script>";
} else {
    echo "ERR!";
}


?>