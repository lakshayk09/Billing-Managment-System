<?php 
session_start();
include('header.php');
include 'DBHelper.php';
$helper = new DBHelper();
$helper->checkLoggedIn();
if(!empty($_POST['productName']) && !empty($_POST['productPrice'])) {
    $helper->saveProduct($_POST);
    header("Location:products.php");
}
?>
<title>Invoice System</title>
<script src="js/jqueryHelper.js"></script>
<link href="css/style.css" rel="stylesheet">
<?php include('container.php');?>
	<div class="container">		
	  <h2 class="title mt-5">Inventory Management</h2>
	  <?php include('menu.php');?>			  
      <table id="data-table" class="table table-condensed table-hover table-striped">
        <thead>
          <tr>
            <th>Product Id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Delete</th>
          </tr>
        </thead>
        <?php		
	    	$productList = $helper->getProductList();
        foreach($productList as $productDetails){
            echo '
              <tr>
                <td>'.$productDetails["product_id"].'</td>
                <td>'.$productDetails["product_name"].'</td>
                <td>Rs. '.$productDetails["product_price"].'</td>
                <td><a href="delete_product.php?product_id='.$productDetails['product_id'].'" title="Delete Product"><button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button></a></td>
              </tr>
            ';
        }       
        ?>
      </table>

      
      <div class="row">
          <form method="post" action="">
              <h4 class="mt-2">Product Details:</h4>
            <div class="form-group">
                <input type="text" name="productName" id="productName" class="form-control" autocomplete="off" placeholder="Product Name"></td>
                <input type="text" name="productPrice" id="productPrice" class="form-control quantity" autocomplete="off" placeholder="Product Price"></td>
            </div>
            <button type="submit" name="addProduct" class="btn btn-success">Add Product</button>
          </form>
       </div>	
</div>	
<?php include('footer.php');?>